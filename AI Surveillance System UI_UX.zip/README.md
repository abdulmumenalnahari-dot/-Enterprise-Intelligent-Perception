
  # AI Surveillance System UI/UX

  This is a code bundle for AI Surveillance System UI/UX. The original project is available at https://www.figma.com/design/JuP4bjCtXtMDT2fz9R9qd3/AI-Surveillance-System-UI-UX.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  