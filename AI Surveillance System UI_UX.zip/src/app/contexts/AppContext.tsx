import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';

export type Language = 'ar' | 'en';
export type Theme = 'dark' | 'light';
export type ColorPreset = 'default' | 'gold' | 'highContrast' | 'custom';
export type FontSize = 'small' | 'medium' | 'large' | 'extraLarge';
export type ContrastMode = 'normal' | 'high';

interface StateColors {
  satisfaction: { high: string; medium: string; low: string };
  attention: { high: string; medium: string; low: string };
  stress: { low: string; medium: string; high: string };
  risk: { none: string; low: string; medium: string; high: string; critical: string };
  system: { online: string; offline: string; warning: string; error: string };
}

interface AppContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  theme: Theme;
  setTheme: (theme: Theme) => void;
  colorPreset: ColorPreset;
  setColorPreset: (preset: ColorPreset) => void;
  fontSize: FontSize;
  setFontSize: (size: FontSize) => void;
  contrastMode: ContrastMode;
  setContrastMode: (mode: ContrastMode) => void;
  stateColors: StateColors;
  setStateColors: (colors: StateColors) => void;
  isAuthenticated: boolean;
  setIsAuthenticated: (auth: boolean) => void;
  isSetupComplete: boolean;
  setIsSetupComplete: (complete: boolean) => void;
}

const defaultStateColors: StateColors = {
  satisfaction: { 
    high: '#10b981', 
    medium: '#f59e0b', 
    low: '#ef4444' 
  },
  attention: { 
    high: '#3b82f6', 
    medium: '#8b5cf6', 
    low: '#6b7280' 
  },
  stress: { 
    low: '#10b981', 
    medium: '#f59e0b', 
    high: '#ef4444' 
  },
  risk: { 
    none: '#10b981', 
    low: '#3b82f6', 
    medium: '#f59e0b', 
    high: '#f97316', 
    critical: '#dc2626' 
  },
  system: { 
    online: '#10b981', 
    offline: '#6b7280', 
    warning: '#f59e0b', 
    error: '#ef4444' 
  }
};

const goldStateColors: StateColors = {
  satisfaction: { 
    high: '#fbbf24', 
    medium: '#f59e0b', 
    low: '#ea580c' 
  },
  attention: { 
    high: '#fbbf24', 
    medium: '#d97706', 
    low: '#78716c' 
  },
  stress: { 
    low: '#fbbf24', 
    medium: '#f59e0b', 
    high: '#ea580c' 
  },
  risk: { 
    none: '#fbbf24', 
    low: '#f59e0b', 
    medium: '#f97316', 
    high: '#ea580c', 
    critical: '#dc2626' 
  },
  system: { 
    online: '#fbbf24', 
    offline: '#78716c', 
    warning: '#f59e0b', 
    error: '#ea580c' 
  }
};

const highContrastColors: StateColors = {
  satisfaction: { 
    high: '#00ff00', 
    medium: '#ffff00', 
    low: '#ff0000' 
  },
  attention: { 
    high: '#00ffff', 
    medium: '#ff00ff', 
    low: '#808080' 
  },
  stress: { 
    low: '#00ff00', 
    medium: '#ffff00', 
    high: '#ff0000' 
  },
  risk: { 
    none: '#00ff00', 
    low: '#00ffff', 
    medium: '#ffff00', 
    high: '#ff8800', 
    critical: '#ff0000' 
  },
  system: { 
    online: '#00ff00', 
    offline: '#808080', 
    warning: '#ffff00', 
    error: '#ff0000' 
  }
};

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [language, setLanguage] = useState<Language>('ar');
  const [theme, setTheme] = useState<Theme>('dark');
  const [colorPreset, setColorPreset] = useState<ColorPreset>('default');
  const [fontSize, setFontSize] = useState<FontSize>('medium');
  const [contrastMode, setContrastMode] = useState<ContrastMode>('normal');
  const [stateColors, setStateColors] = useState<StateColors>(defaultStateColors);
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [isSetupComplete, setIsSetupComplete] = useState(false);

  useEffect(() => {
    const root = document.documentElement;
    root.setAttribute('dir', language === 'ar' ? 'rtl' : 'ltr');
    root.setAttribute('lang', language);
    
    // Set font family based on language
    if (language === 'ar') {
      root.style.fontFamily = "'Tajawal', 'IBM Plex Sans Arabic', sans-serif";
    } else {
      root.style.fontFamily = "'Inter', 'IBM Plex Sans', sans-serif";
    }
  }, [language]);

  useEffect(() => {
    const root = document.documentElement;
    if (theme === 'dark') {
      root.classList.add('dark');
    } else {
      root.classList.remove('dark');
    }
  }, [theme]);

  useEffect(() => {
    const fontSizes = {
      small: '14px',
      medium: '16px',
      large: '18px',
      extraLarge: '20px'
    };
    document.documentElement.style.setProperty('--font-size', fontSizes[fontSize]);
  }, [fontSize]);

  useEffect(() => {
    switch (colorPreset) {
      case 'gold':
        setStateColors(goldStateColors);
        break;
      case 'highContrast':
        setStateColors(highContrastColors);
        break;
      case 'default':
      default:
        setStateColors(defaultStateColors);
        break;
    }
  }, [colorPreset]);

  return (
    <AppContext.Provider
      value={{
        language,
        setLanguage,
        theme,
        setTheme,
        colorPreset,
        setColorPreset,
        fontSize,
        setFontSize,
        contrastMode,
        setContrastMode,
        stateColors,
        setStateColors,
        isAuthenticated,
        setIsAuthenticated,
        isSetupComplete,
        setIsSetupComplete
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within AppProvider');
  }
  return context;
};
