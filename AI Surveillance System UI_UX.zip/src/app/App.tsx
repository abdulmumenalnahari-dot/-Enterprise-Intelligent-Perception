import React, { useState, useEffect } from 'react';
import { AppProvider, useApp } from './contexts/AppContext';
import { SplashScreen } from './components/SplashScreen';
import { LoginScreen } from './components/LoginScreen';
import { SetupWizard } from './components/SetupWizard';
import { Layout } from './components/Layout';
import { Dashboard } from './components/Dashboard';
import { CameraWall } from './components/CameraWall';
import { Analytics } from './components/Analytics';
import { Alerts } from './components/Alerts';
import { Reports } from './components/Reports';
import { Profiles } from './components/Profiles';
import { Settings } from './components/Settings';
import { Toaster } from './components/ui/sonner';

type AppState = 'splash' | 'login' | 'setup' | 'app';
type Page = 'dashboard' | 'cameraWall' | 'analytics' | 'alerts' | 'reports' | 'profiles' | 'settings';

function AppContent() {
  const { isAuthenticated, isSetupComplete, setIsAuthenticated, setIsSetupComplete } = useApp();
  const [appState, setAppState] = useState<AppState>('splash');
  const [currentPage, setCurrentPage] = useState<Page>('dashboard');

  useEffect(() => {
    // Determine app state based on authentication and setup
    if (!isAuthenticated) {
      setAppState('login');
    } else if (!isSetupComplete) {
      setAppState('setup');
    } else {
      setAppState('app');
    }
  }, [isAuthenticated, isSetupComplete]);

  const handleSplashComplete = () => {
    setAppState('login');
  };

  const handleLogin = () => {
    setIsAuthenticated(true);
  };

  const handleSetupComplete = () => {
    setIsSetupComplete(true);
  };

  const handleNavigate = (page: string) => {
    setCurrentPage(page as Page);
  };

  const renderPage = () => {
    switch (currentPage) {
      case 'dashboard':
        return <Dashboard onNavigate={handleNavigate} />;
      case 'cameraWall':
        return <CameraWall />;
      case 'analytics':
        return <Analytics />;
      case 'alerts':
        return <Alerts />;
      case 'reports':
        return <Reports />;
      case 'profiles':
        return <Profiles />;
      case 'settings':
        return <Settings />;
      default:
        return <Dashboard onNavigate={handleNavigate} />;
    }
  };

  if (appState === 'splash') {
    return <SplashScreen onComplete={handleSplashComplete} />;
  }

  if (appState === 'login') {
    return <LoginScreen onLogin={handleLogin} />;
  }

  if (appState === 'setup') {
    return <SetupWizard onComplete={handleSetupComplete} />;
  }

  return (
    <Layout currentPage={currentPage} onNavigate={handleNavigate}>
      {renderPage()}
    </Layout>
  );
}

export default function App() {
  return (
    <AppProvider>
      <AppContent />
      <Toaster />
    </AppProvider>
  );
}
