import React from 'react';
import { useApp } from '../contexts/AppContext';
import { t } from '../i18n/translations';
import { Card } from './ui/card';
import { Label } from './ui/label';
import { Switch } from './ui/switch';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Slider } from './ui/slider';
import { Button } from './ui/button';
import { Palette, Type, Accessibility, Save, RotateCcw } from 'lucide-react';

export const Settings: React.FC = () => {
  const {
    language,
    setLanguage,
    theme,
    setTheme,
    colorPreset,
    setColorPreset,
    fontSize,
    setFontSize,
    contrastMode,
    setContrastMode,
    stateColors,
    setStateColors
  } = useApp();

  const fontSizeValue = {
    small: 14,
    medium: 16,
    large: 18,
    extraLarge: 20
  }[fontSize];

  const handleFontSizeChange = (value: number[]) => {
    const size = value[0];
    if (size <= 14) setFontSize('small');
    else if (size <= 16) setFontSize('medium');
    else if (size <= 18) setFontSize('large');
    else setFontSize('extraLarge');
  };

  return (
    <div className="space-y-6 max-w-4xl">
      {/* General Settings */}
      <Card className="bg-slate-900/50 border-slate-800 p-6">
        <div className="flex items-center gap-3 mb-6">
          <div className="w-10 h-10 bg-gradient-to-br from-cyan-500/20 to-blue-600/20 rounded-lg flex items-center justify-center">
            <Type className="w-5 h-5 text-cyan-400" />
          </div>
          <h2 className="text-xl font-bold text-white">{t('general', language)}</h2>
        </div>

        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <div>
              <Label className="text-white">{t('language', language)}</Label>
              <p className="text-slate-400 text-sm mt-1">
                {language === 'ar' ? 'اختر لغة الواجهة' : 'Choose interface language'}
              </p>
            </div>
            <div className="flex gap-2">
              <button
                onClick={() => setLanguage('ar')}
                className={`px-4 py-2 rounded-lg transition-all ${
                  language === 'ar'
                    ? 'bg-gradient-to-r from-cyan-500 to-blue-600 text-white shadow-lg'
                    : 'bg-slate-800 text-slate-400 hover:text-white'
                }`}
              >
                عربي
              </button>
              <button
                onClick={() => setLanguage('en')}
                className={`px-4 py-2 rounded-lg transition-all ${
                  language === 'en'
                    ? 'bg-gradient-to-r from-cyan-500 to-blue-600 text-white shadow-lg'
                    : 'bg-slate-800 text-slate-400 hover:text-white'
                }`}
              >
                English
              </button>
            </div>
          </div>

          <div className="h-px bg-slate-800" />

          <div className="flex items-center justify-between">
            <div>
              <Label className="text-white">{t('theme', language)}</Label>
              <p className="text-slate-400 text-sm mt-1">
                {language === 'ar' ? 'تبديل بين الوضع الفاتح والداكن' : 'Toggle between light and dark mode'}
              </p>
            </div>
            <div className="flex items-center gap-3">
              <span className={`text-sm ${theme === 'light' ? 'text-white' : 'text-slate-400'}`}>
                {t('lightMode', language)}
              </span>
              <Switch
                checked={theme === 'dark'}
                onCheckedChange={(checked) => setTheme(checked ? 'dark' : 'light')}
              />
              <span className={`text-sm ${theme === 'dark' ? 'text-white' : 'text-slate-400'}`}>
                {t('darkMode', language)}
              </span>
            </div>
          </div>
        </div>
      </Card>

      {/* Appearance */}
      <Card className="bg-slate-900/50 border-slate-800 p-6">
        <div className="flex items-center gap-3 mb-6">
          <div className="w-10 h-10 bg-gradient-to-br from-purple-500/20 to-pink-600/20 rounded-lg flex items-center justify-center">
            <Palette className="w-5 h-5 text-purple-400" />
          </div>
          <h2 className="text-xl font-bold text-white">{t('appearance', language)}</h2>
        </div>

        <div className="space-y-6">
          <div>
            <Label className="text-white mb-3 block">{t('colorPreset', language)}</Label>
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <button
                onClick={() => setColorPreset('default')}
                className={`p-4 rounded-lg border-2 transition-all ${
                  colorPreset === 'default'
                    ? 'border-cyan-500 bg-cyan-500/10'
                    : 'border-slate-700 hover:border-slate-600'
                }`}
              >
                <div className="flex gap-2 mb-2">
                  <div className="w-6 h-6 rounded bg-green-500" />
                  <div className="w-6 h-6 rounded bg-blue-500" />
                  <div className="w-6 h-6 rounded bg-orange-500" />
                </div>
                <p className="text-white text-sm font-medium">{t('default', language)}</p>
              </button>

              <button
                onClick={() => setColorPreset('gold')}
                className={`p-4 rounded-lg border-2 transition-all ${
                  colorPreset === 'gold'
                    ? 'border-yellow-500 bg-yellow-500/10'
                    : 'border-slate-700 hover:border-slate-600'
                }`}
              >
                <div className="flex gap-2 mb-2">
                  <div className="w-6 h-6 rounded bg-yellow-400" />
                  <div className="w-6 h-6 rounded bg-amber-500" />
                  <div className="w-6 h-6 rounded bg-orange-600" />
                </div>
                <p className="text-white text-sm font-medium">{t('gold', language)}</p>
              </button>

              <button
                onClick={() => setColorPreset('highContrast')}
                className={`p-4 rounded-lg border-2 transition-all ${
                  colorPreset === 'highContrast'
                    ? 'border-white bg-white/10'
                    : 'border-slate-700 hover:border-slate-600'
                }`}
              >
                <div className="flex gap-2 mb-2">
                  <div className="w-6 h-6 rounded bg-lime-400" />
                  <div className="w-6 h-6 rounded bg-cyan-400" />
                  <div className="w-6 h-6 rounded bg-yellow-300" />
                </div>
                <p className="text-white text-sm font-medium">{t('highContrast', language)}</p>
              </button>

              <button
                onClick={() => setColorPreset('custom')}
                className={`p-4 rounded-lg border-2 transition-all ${
                  colorPreset === 'custom'
                    ? 'border-purple-500 bg-purple-500/10'
                    : 'border-slate-700 hover:border-slate-600'
                }`}
              >
                <div className="flex gap-2 mb-2">
                  <div className="w-6 h-6 rounded bg-gradient-to-br from-purple-400 to-pink-600" />
                  <div className="w-6 h-6 rounded bg-gradient-to-br from-cyan-400 to-blue-600" />
                  <div className="w-6 h-6 rounded bg-gradient-to-br from-orange-400 to-red-600" />
                </div>
                <p className="text-white text-sm font-medium">{t('custom', language)}</p>
              </button>
            </div>
          </div>

          <div className="h-px bg-slate-800" />

          <div>
            <Label className="text-white mb-3 block">{t('fontSize', language)}</Label>
            <div className="flex items-center gap-4">
              <span className="text-slate-400 text-sm w-12">{fontSizeValue}px</span>
              <Slider
                value={[fontSizeValue]}
                min={14}
                max={20}
                step={1}
                onValueChange={handleFontSizeChange}
                className="flex-1"
              />
              <div className="flex gap-2">
                <span className={`text-xs ${fontSize === 'small' ? 'text-cyan-400' : 'text-slate-500'}`}>A</span>
                <span className={`text-sm ${fontSize === 'medium' ? 'text-cyan-400' : 'text-slate-500'}`}>A</span>
                <span className={`text-base ${fontSize === 'large' ? 'text-cyan-400' : 'text-slate-500'}`}>A</span>
                <span className={`text-lg ${fontSize === 'extraLarge' ? 'text-cyan-400' : 'text-slate-500'}`}>A</span>
              </div>
            </div>
          </div>
        </div>
      </Card>

      {/* Accessibility */}
      <Card className="bg-slate-900/50 border-slate-800 p-6">
        <div className="flex items-center gap-3 mb-6">
          <div className="w-10 h-10 bg-gradient-to-br from-green-500/20 to-emerald-600/20 rounded-lg flex items-center justify-center">
            <Accessibility className="w-5 h-5 text-green-400" />
          </div>
          <h2 className="text-xl font-bold text-white">{t('accessibility', language)}</h2>
        </div>

        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <div>
              <Label className="text-white">{language === 'ar' ? 'وضع التباين العالي' : 'High Contrast Mode'}</Label>
              <p className="text-slate-400 text-sm mt-1">
                {language === 'ar' ? 'تحسين الرؤية للمستخدمين ضعاف البصر' : 'Improve visibility for users with low vision'}
              </p>
            </div>
            <Switch
              checked={contrastMode === 'high'}
              onCheckedChange={(checked) => setContrastMode(checked ? 'high' : 'normal')}
            />
          </div>

          <div className="h-px bg-slate-800" />

          <div className="bg-slate-800/50 border border-slate-700 rounded-lg p-4">
            <h4 className="text-white font-medium mb-2">
              {language === 'ar' ? 'معاينة الألوان الحالية' : 'Current Color Preview'}
            </h4>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
              <div className="space-y-2">
                <p className="text-slate-400 text-xs">{t('satisfaction', language)}</p>
                <div className="flex gap-1">
                  <div className="w-8 h-8 rounded" style={{ backgroundColor: stateColors.satisfaction.high }} />
                  <div className="w-8 h-8 rounded" style={{ backgroundColor: stateColors.satisfaction.medium }} />
                  <div className="w-8 h-8 rounded" style={{ backgroundColor: stateColors.satisfaction.low }} />
                </div>
              </div>
              <div className="space-y-2">
                <p className="text-slate-400 text-xs">{t('attention', language)}</p>
                <div className="flex gap-1">
                  <div className="w-8 h-8 rounded" style={{ backgroundColor: stateColors.attention.high }} />
                  <div className="w-8 h-8 rounded" style={{ backgroundColor: stateColors.attention.medium }} />
                  <div className="w-8 h-8 rounded" style={{ backgroundColor: stateColors.attention.low }} />
                </div>
              </div>
              <div className="space-y-2">
                <p className="text-slate-400 text-xs">{t('stress', language)}</p>
                <div className="flex gap-1">
                  <div className="w-8 h-8 rounded" style={{ backgroundColor: stateColors.stress.low }} />
                  <div className="w-8 h-8 rounded" style={{ backgroundColor: stateColors.stress.medium }} />
                  <div className="w-8 h-8 rounded" style={{ backgroundColor: stateColors.stress.high }} />
                </div>
              </div>
            </div>
          </div>
        </div>
      </Card>

      {/* Actions */}
      <div className="flex gap-4">
        <Button className="bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-600 hover:to-blue-700">
          <Save className="w-4 h-4 mr-2" />
          {t('save', language)}
        </Button>
        <Button variant="outline" className="border-slate-700 text-white hover:bg-slate-800">
          <RotateCcw className="w-4 h-4 mr-2" />
          {language === 'ar' ? 'إعادة تعيين' : 'Reset'}
        </Button>
      </div>
    </div>
  );
};
