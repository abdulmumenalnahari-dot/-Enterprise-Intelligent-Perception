import React from 'react';
import { useApp } from '../contexts/AppContext';
import { t } from '../i18n/translations';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { FileText, Download, Calendar, Filter } from 'lucide-react';

export const Reports: React.FC = () => {
  const { language } = useApp();

  const reports = [
    {
      id: '1',
      title: language === 'ar' ? 'تقرير الرضا اليومي' : 'Daily Satisfaction Report',
      date: '2026-01-10',
      type: language === 'ar' ? 'رضا' : 'Satisfaction',
      size: '2.4 MB'
    },
    {
      id: '2',
      title: language === 'ar' ? 'تقرير الانتباه الأسبوعي' : 'Weekly Attention Report',
      date: '2026-01-10',
      type: language === 'ar' ? 'انتباه' : 'Attention',
      size: '5.1 MB'
    },
    {
      id: '3',
      title: language === 'ar' ? 'تقرير الإجهاد الشهري' : 'Monthly Stress Report',
      date: '2026-01-01',
      type: language === 'ar' ? 'إجهاد' : 'Stress',
      size: '12.3 MB'
    },
    {
      id: '4',
      title: language === 'ar' ? 'تقرير التنبيهات' : 'Alerts Summary Report',
      date: '2026-01-10',
      type: language === 'ar' ? 'تنبيهات' : 'Alerts',
      size: '1.8 MB'
    }
  ];

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-white">{t('reports', language)}</h2>
          <p className="text-slate-400 mt-1">
            {language === 'ar' ? 'إنشاء وتحميل التقارير التحليلية' : 'Generate and download analytical reports'}
          </p>
        </div>
        <Button className="bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-600 hover:to-blue-700">
          <FileText className="w-4 h-4 mr-2" />
          {language === 'ar' ? 'إنشاء تقرير جديد' : 'Generate New Report'}
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {reports.map(report => (
          <Card key={report.id} className="bg-slate-900/50 border-slate-800 p-6">
            <div className="flex items-start justify-between mb-4">
              <div className="w-12 h-12 bg-gradient-to-br from-cyan-500/20 to-blue-600/20 rounded-lg flex items-center justify-center">
                <FileText className="w-6 h-6 text-cyan-400" />
              </div>
            </div>
            <h3 className="text-white font-medium mb-2">{report.title}</h3>
            <div className="space-y-1 mb-4">
              <p className="text-slate-400 text-sm flex items-center gap-2">
                <Calendar className="w-4 h-4" />
                {report.date}
              </p>
              <p className="text-slate-400 text-sm">{report.size}</p>
            </div>
            <Button variant="outline" className="w-full border-slate-700 text-white hover:bg-slate-800">
              <Download className="w-4 h-4 mr-2" />
              {t('export', language)}
            </Button>
          </Card>
        ))}
      </div>
    </div>
  );
};
