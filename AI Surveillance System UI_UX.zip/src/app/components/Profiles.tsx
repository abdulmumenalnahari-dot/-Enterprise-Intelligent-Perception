import React from 'react';
import { useApp } from '../contexts/AppContext';
import { t } from '../i18n/translations';
import { Card } from './ui/card';
import { Badge } from './ui/badge';
import { User, Clock, Camera, TrendingUp, TrendingDown } from 'lucide-react';

export const Profiles: React.FC = () => {
  const { language, stateColors } = useApp();

  const profiles = [
    {
      id: 'P1247',
      firstSeen: '2026-01-10 08:23',
      lastSeen: '2026-01-10 14:45',
      cameras: ['Airport Terminal 2', 'Airport Security'],
      satisfaction: 'medium',
      attention: 'high',
      stress: 'low',
      risk: 'low',
      appearances: 12
    },
    {
      id: 'P2891',
      firstSeen: '2026-01-10 09:15',
      lastSeen: '2026-01-10 14:30',
      cameras: ['University Building A 1', 'University Building A 3'],
      satisfaction: 'high',
      attention: 'high',
      stress: 'low',
      risk: 'none',
      appearances: 8
    },
    {
      id: 'P3456',
      firstSeen: '2026-01-10 10:00',
      lastSeen: '2026-01-10 14:25',
      cameras: ['Supermarket Floor 1', 'Supermarket Floor 2'],
      satisfaction: 'low',
      attention: 'medium',
      stress: 'high',
      risk: 'none',
      appearances: 15
    }
  ];

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold text-white">{t('profiles', language)}</h2>
        <p className="text-slate-400 mt-1">
          {language === 'ar' ? 'ملفات الأشخاص المكتشفين' : 'Detected person profiles'}
        </p>
      </div>

      <div className="grid grid-cols-1 gap-6">
        {profiles.map(profile => (
          <Card key={profile.id} className="bg-slate-900/50 border-slate-800 p-6">
            <div className="flex items-start gap-6">
              <div className="w-20 h-20 bg-gradient-to-br from-cyan-500/20 to-blue-600/20 rounded-lg flex items-center justify-center flex-shrink-0">
                <User className="w-10 h-10 text-cyan-400" />
              </div>

              <div className="flex-1">
                <div className="flex items-start justify-between mb-4">
                  <div>
                    <h3 className="text-xl font-bold text-white mb-2">{language === 'ar' ? 'معرف' : 'ID'}: {profile.id}</h3>
                    <div className="flex items-center gap-4 text-sm text-slate-400">
                      <span className="flex items-center gap-1">
                        <Clock className="w-4 h-4" />
                        {language === 'ar' ? 'أول ظهور' : 'First seen'}: {profile.firstSeen}
                      </span>
                      <span className="flex items-center gap-1">
                        <Clock className="w-4 h-4" />
                        {language === 'ar' ? 'آخر ظهور' : 'Last seen'}: {profile.lastSeen}
                      </span>
                    </div>
                  </div>
                  <Badge variant="outline" className="border-cyan-500 text-cyan-400">
                    {profile.appearances} {language === 'ar' ? 'ظهور' : 'appearances'}
                  </Badge>
                </div>

                <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-4">
                  <div className="bg-slate-800/50 rounded-lg p-3">
                    <p className="text-slate-400 text-xs mb-1">{t('satisfaction', language)}</p>
                    <p className="text-white font-medium capitalize" style={{ color: stateColors.satisfaction[profile.satisfaction as keyof typeof stateColors.satisfaction] }}>
                      {profile.satisfaction}
                    </p>
                  </div>
                  <div className="bg-slate-800/50 rounded-lg p-3">
                    <p className="text-slate-400 text-xs mb-1">{t('attention', language)}</p>
                    <p className="text-white font-medium capitalize" style={{ color: stateColors.attention[profile.attention as keyof typeof stateColors.attention] }}>
                      {profile.attention}
                    </p>
                  </div>
                  <div className="bg-slate-800/50 rounded-lg p-3">
                    <p className="text-slate-400 text-xs mb-1">{t('stress', language)}</p>
                    <p className="text-white font-medium capitalize" style={{ color: stateColors.stress[profile.stress as keyof typeof stateColors.stress] }}>
                      {profile.stress}
                    </p>
                  </div>
                  <div className="bg-slate-800/50 rounded-lg p-3">
                    <p className="text-slate-400 text-xs mb-1">{t('risk', language)}</p>
                    <p className="text-white font-medium capitalize" style={{ color: stateColors.risk[profile.risk as keyof typeof stateColors.risk] }}>
                      {profile.risk}
                    </p>
                  </div>
                </div>

                <div className="bg-slate-800/30 rounded-lg p-3">
                  <p className="text-slate-400 text-sm mb-2 flex items-center gap-2">
                    <Camera className="w-4 h-4" />
                    {language === 'ar' ? 'الكاميرات' : 'Cameras'}:
                  </p>
                  <div className="flex flex-wrap gap-2">
                    {profile.cameras.map((cam, i) => (
                      <Badge key={i} variant="outline" className="border-slate-700 text-slate-300">
                        {cam}
                      </Badge>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </Card>
        ))}
      </div>
    </div>
  );
};
