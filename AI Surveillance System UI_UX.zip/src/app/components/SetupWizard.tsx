import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { useApp } from '../contexts/AppContext';
import { t } from '../i18n/translations';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Check, ChevronRight, ChevronLeft, Settings, Camera, Brain, CheckCircle2 } from 'lucide-react';

export const SetupWizard: React.FC<{ onComplete: () => void }> = ({ onComplete }) => {
  const { language } = useApp();
  const [step, setStep] = useState(0);
  const [config, setConfig] = useState({
    organizationName: '',
    timezone: 'UTC+3',
    cameraCount: '10',
    aiModel: 'advanced',
    enableRealtime: true
  });

  const steps = [
    {
      icon: Settings,
      titleKey: 'systemConfiguration' as const,
      component: (
        <div className="space-y-6">
          <div className="space-y-2">
            <Label className="text-slate-300">
              {language === 'ar' ? 'اسم المؤسسة' : 'Organization Name'}
            </Label>
            <Input
              value={config.organizationName}
              onChange={(e) => setConfig({ ...config, organizationName: e.target.value })}
              className="bg-slate-800/50 border-slate-700 text-white"
              placeholder={language === 'ar' ? 'أدخل اسم المؤسسة' : 'Enter organization name'}
            />
          </div>
          <div className="space-y-2">
            <Label className="text-slate-300">
              {language === 'ar' ? 'المنطقة الزمنية' : 'Timezone'}
            </Label>
            <Select value={config.timezone} onValueChange={(v) => setConfig({ ...config, timezone: v })}>
              <SelectTrigger className="bg-slate-800/50 border-slate-700 text-white">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="UTC+3">UTC+3 (Arabia)</SelectItem>
                <SelectItem value="UTC+2">UTC+2 (Cairo)</SelectItem>
                <SelectItem value="UTC+1">UTC+1 (Central Europe)</SelectItem>
                <SelectItem value="UTC+0">UTC+0 (GMT)</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
      )
    },
    {
      icon: Camera,
      titleKey: 'cameraSetup' as const,
      component: (
        <div className="space-y-6">
          <div className="space-y-2">
            <Label className="text-slate-300">
              {language === 'ar' ? 'عدد الكاميرات' : 'Number of Cameras'}
            </Label>
            <Select value={config.cameraCount} onValueChange={(v) => setConfig({ ...config, cameraCount: v })}>
              <SelectTrigger className="bg-slate-800/50 border-slate-700 text-white">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="5">5 {language === 'ar' ? 'كاميرات' : 'Cameras'}</SelectItem>
                <SelectItem value="10">10 {language === 'ar' ? 'كاميرات' : 'Cameras'}</SelectItem>
                <SelectItem value="20">20 {language === 'ar' ? 'كاميرا' : 'Cameras'}</SelectItem>
                <SelectItem value="50">50 {language === 'ar' ? 'كاميرا' : 'Cameras'}</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="bg-slate-800/30 border border-slate-700/50 rounded-lg p-4">
            <p className="text-slate-400 text-sm">
              {language === 'ar'
                ? 'سيتم تكوين الكاميرات تلقائياً عند اكتشافها على الشبكة'
                : 'Cameras will be auto-configured when detected on the network'}
            </p>
          </div>
        </div>
      )
    },
    {
      icon: Brain,
      titleKey: 'aiConfiguration' as const,
      component: (
        <div className="space-y-6">
          <div className="space-y-2">
            <Label className="text-slate-300">
              {language === 'ar' ? 'نموذج الذكاء الاصطناعي' : 'AI Model'}
            </Label>
            <Select value={config.aiModel} onValueChange={(v) => setConfig({ ...config, aiModel: v })}>
              <SelectTrigger className="bg-slate-800/50 border-slate-700 text-white">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="basic">
                  {language === 'ar' ? 'أساسي - سريع' : 'Basic - Fast'}
                </SelectItem>
                <SelectItem value="advanced">
                  {language === 'ar' ? 'متقدم - موصى به' : 'Advanced - Recommended'}
                </SelectItem>
                <SelectItem value="premium">
                  {language === 'ar' ? 'متميز - دقة عالية' : 'Premium - High Accuracy'}
                </SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-3">
            <div className="flex items-center justify-between bg-slate-800/30 border border-slate-700/50 rounded-lg p-4">
              <span className="text-slate-300">
                {language === 'ar' ? 'تحليل في الوقت الفعلي' : 'Real-time Analysis'}
              </span>
              <div className="flex items-center gap-2">
                <span className="text-cyan-400 text-sm">
                  {language === 'ar' ? 'مفعّل' : 'Enabled'}
                </span>
                <Check className="w-5 h-5 text-cyan-400" />
              </div>
            </div>
            <div className="flex items-center justify-between bg-slate-800/30 border border-slate-700/50 rounded-lg p-4">
              <span className="text-slate-300">
                {language === 'ar' ? 'كشف متعدد الأشخاص' : 'Multi-person Detection'}
              </span>
              <div className="flex items-center gap-2">
                <span className="text-cyan-400 text-sm">
                  {language === 'ar' ? 'مفعّل' : 'Enabled'}
                </span>
                <Check className="w-5 h-5 text-cyan-400" />
              </div>
            </div>
          </div>
        </div>
      )
    },
    {
      icon: CheckCircle2,
      titleKey: 'setupComplete' as const,
      component: (
        <div className="text-center space-y-6">
          <div className="inline-flex items-center justify-center w-20 h-20 bg-gradient-to-br from-green-400 to-emerald-600 rounded-full shadow-lg shadow-green-500/30">
            <CheckCircle2 className="w-12 h-12 text-white" />
          </div>
          <div>
            <h3 className="text-xl font-bold text-white mb-2">
              {language === 'ar' ? 'الإعداد مكتمل!' : 'Setup Complete!'}
            </h3>
            <p className="text-slate-400">
              {language === 'ar'
                ? 'النظام جاهز للاستخدام'
                : 'System is ready to use'}
            </p>
          </div>
          <div className="bg-slate-800/30 border border-slate-700/50 rounded-lg p-4 space-y-2 text-right">
            <div className="flex justify-between text-sm">
              <span className="text-slate-400">{language === 'ar' ? 'المؤسسة:' : 'Organization:'}</span>
              <span className="text-white">{config.organizationName || 'N/A'}</span>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-slate-400">{language === 'ar' ? 'الكاميرات:' : 'Cameras:'}</span>
              <span className="text-white">{config.cameraCount}</span>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-slate-400">{language === 'ar' ? 'نموذج AI:' : 'AI Model:'}</span>
              <span className="text-white capitalize">{config.aiModel}</span>
            </div>
          </div>
        </div>
      )
    }
  ];

  const currentStep = steps[step];
  const Icon = currentStep.icon;

  const handleNext = () => {
    if (step < steps.length - 1) {
      setStep(step + 1);
    } else {
      onComplete();
    }
  };

  const handleBack = () => {
    if (step > 0) {
      setStep(step - 1);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-blue-950 to-slate-900 flex items-center justify-center p-4">
      <div className="w-full max-w-2xl">
        {/* Progress Steps */}
        <div className="mb-8">
          <div className="flex items-center justify-between mb-4">
            {steps.map((s, i) => {
              const StepIcon = s.icon;
              return (
                <React.Fragment key={i}>
                  <div className="flex flex-col items-center gap-2">
                    <div
                      className={`w-12 h-12 rounded-full flex items-center justify-center transition-all ${
                        i <= step
                          ? 'bg-gradient-to-br from-cyan-400 to-blue-600 shadow-lg shadow-cyan-500/30'
                          : 'bg-slate-800 border border-slate-700'
                      }`}
                    >
                      {i < step ? (
                        <Check className="w-6 h-6 text-white" />
                      ) : (
                        <StepIcon className={`w-6 h-6 ${i <= step ? 'text-white' : 'text-slate-500'}`} />
                      )}
                    </div>
                    <span className={`text-xs ${i <= step ? 'text-white' : 'text-slate-500'}`}>
                      {i + 1}
                    </span>
                  </div>
                  {i < steps.length - 1 && (
                    <div className={`flex-1 h-1 mx-2 rounded ${i < step ? 'bg-gradient-to-r from-cyan-400 to-blue-600' : 'bg-slate-800'}`} />
                  )}
                </React.Fragment>
              );
            })}
          </div>
        </div>

        {/* Main Card */}
        <motion.div
          key={step}
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          exit={{ opacity: 0, x: -20 }}
          transition={{ duration: 0.3 }}
          className="bg-slate-900/80 backdrop-blur-xl border border-slate-700/50 rounded-2xl shadow-2xl p-8"
        >
          <div className="mb-8">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-12 h-12 bg-gradient-to-br from-cyan-400/20 to-blue-600/20 rounded-lg flex items-center justify-center">
                <Icon className="w-6 h-6 text-cyan-400" />
              </div>
              <h2 className="text-2xl font-bold text-white">
                {t(currentStep.titleKey, language)}
              </h2>
            </div>
          </div>

          <div className="mb-8">
            {currentStep.component}
          </div>

          {/* Navigation */}
          <div className="flex justify-between gap-4">
            <Button
              onClick={handleBack}
              disabled={step === 0}
              variant="outline"
              className="border-slate-700 text-slate-300 hover:bg-slate-800"
            >
              {language === 'ar' ? (
                <>
                  {t('back', language)}
                  <ChevronRight className="w-4 h-4 mr-2" />
                </>
              ) : (
                <>
                  <ChevronLeft className="w-4 h-4 mr-2" />
                  {t('back', language)}
                </>
              )}
            </Button>
            <Button
              onClick={handleNext}
              className="bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-600 hover:to-blue-700 text-white shadow-lg shadow-cyan-500/30"
            >
              {language === 'ar' ? (
                <>
                  {step === steps.length - 1 ? t('finish', language) : t('next', language)}
                  <ChevronLeft className="w-4 h-4 mr-2" />
                </>
              ) : (
                <>
                  {step === steps.length - 1 ? t('finish', language) : t('next', language)}
                  <ChevronRight className="w-4 h-4 ml-2" />
                </>
              )}
            </Button>
          </div>
        </motion.div>
      </div>
    </div>
  );
};
