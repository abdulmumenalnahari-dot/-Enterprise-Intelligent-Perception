import React, { useState } from 'react';
import { useApp } from '../contexts/AppContext';
import { t } from '../i18n/translations';
import { LineChart, Line, BarChart, Bar, PieChart, Pie, Cell, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, Area, AreaChart } from 'recharts';
import { Card } from './ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Calendar, TrendingUp, Users, Smile, Eye, Zap, Download } from 'lucide-react';
import { Button } from './ui/button';

export const Analytics: React.FC = () => {
  const { language, stateColors } = useApp();
  const [timeRange, setTimeRange] = useState('24h');
  const [selectedContext, setSelectedContext] = useState('all');

  // Generate mock analytics data
  const hourlyData = Array.from({ length: 24 }, (_, i) => ({
    hour: `${i.toString().padStart(2, '0')}:00`,
    satisfaction: 65 + Math.random() * 25,
    attention: 55 + Math.random() * 30,
    stress: 20 + Math.random() * 25,
    people: Math.floor(80 + Math.random() * 100)
  }));

  const contextData = [
    { name: t('university', language), satisfaction: 85, attention: 76, stress: 28, people: 245 },
    { name: t('supermarket', language), satisfaction: 72, attention: 58, stress: 42, people: 312 },
    { name: t('serviceCounter', language), satisfaction: 68, attention: 82, stress: 48, people: 156 },
    { name: t('meetingRoom', language), satisfaction: 88, attention: 91, stress: 22, people: 89 },
    { name: t('crowd', language), satisfaction: 74, attention: 52, stress: 38, people: 428 },
    { name: t('airport', language), satisfaction: 79, attention: 74, stress: 35, people: 267 }
  ];

  const satisfactionDistribution = [
    { name: t('satisfactionHigh', language), value: 58, color: stateColors.satisfaction.high },
    { name: t('satisfactionMedium', language), value: 32, color: stateColors.satisfaction.medium },
    { name: t('satisfactionLow', language), value: 10, color: stateColors.satisfaction.low }
  ];

  const attentionDistribution = [
    { name: t('attentionHigh', language), value: 45, color: stateColors.attention.high },
    { name: t('attentionMedium', language), value: 38, color: stateColors.attention.medium },
    { name: t('attentionLow', language), value: 17, color: stateColors.attention.low }
  ];

  const stressDistribution = [
    { name: t('stressLow', language), value: 62, color: stateColors.stress.low },
    { name: t('stressMedium', language), value: 28, color: stateColors.stress.medium },
    { name: t('stressHigh', language), value: 10, color: stateColors.stress.high }
  ];

  const weeklyTrends = Array.from({ length: 7 }, (_, i) => ({
    day: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'][i],
    satisfaction: 70 + Math.random() * 20,
    attention: 65 + Math.random() * 20,
    stress: 25 + Math.random() * 20
  }));

  return (
    <div className="space-y-6">
      {/* Controls */}
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-4">
          <Select value={timeRange} onValueChange={setTimeRange}>
            <SelectTrigger className="w-[180px] bg-slate-900/50 border-slate-800 text-white">
              <div className="flex items-center gap-2">
                <Calendar className="w-4 h-4" />
                <SelectValue />
              </div>
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="24h">{language === 'ar' ? '24 ساعة' : 'Last 24 Hours'}</SelectItem>
              <SelectItem value="7d">{language === 'ar' ? '7 أيام' : 'Last 7 Days'}</SelectItem>
              <SelectItem value="30d">{language === 'ar' ? '30 يوم' : 'Last 30 Days'}</SelectItem>
              <SelectItem value="90d">{language === 'ar' ? '90 يوم' : 'Last 90 Days'}</SelectItem>
            </SelectContent>
          </Select>

          <Select value={selectedContext} onValueChange={setSelectedContext}>
            <SelectTrigger className="w-[200px] bg-slate-900/50 border-slate-800 text-white">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">{language === 'ar' ? 'جميع السياقات' : 'All Contexts'}</SelectItem>
              <SelectItem value="university">{t('university', language)}</SelectItem>
              <SelectItem value="supermarket">{t('supermarket', language)}</SelectItem>
              <SelectItem value="serviceCounter">{t('serviceCounter', language)}</SelectItem>
              <SelectItem value="meetingRoom">{t('meetingRoom', language)}</SelectItem>
              <SelectItem value="crowd">{t('crowd', language)}</SelectItem>
              <SelectItem value="airport">{t('airport', language)}</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <Button className="bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-600 hover:to-blue-700">
          <Download className="w-4 h-4 mr-2" />
          {t('export', language)}
        </Button>
      </div>

      {/* Key Metrics Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card className="bg-gradient-to-br from-green-500/10 to-emerald-600/10 border-green-500/30 p-6">
          <div className="flex items-start justify-between mb-4">
            <div className="w-12 h-12 bg-gradient-to-br from-green-400 to-emerald-600 rounded-lg flex items-center justify-center">
              <Smile className="w-6 h-6 text-white" />
            </div>
            <div className="flex items-center gap-1 text-green-400 text-sm">
              <TrendingUp className="w-4 h-4" />
              <span>+5.2%</span>
            </div>
          </div>
          <h3 className="text-slate-400 text-sm mb-1">{t('satisfaction', language)}</h3>
          <p className="text-3xl font-bold text-white">78.5%</p>
          <p className="text-slate-500 text-xs mt-2">{language === 'ar' ? 'متوسط عام' : 'Overall average'}</p>
        </Card>

        <Card className="bg-gradient-to-br from-blue-500/10 to-cyan-600/10 border-blue-500/30 p-6">
          <div className="flex items-start justify-between mb-4">
            <div className="w-12 h-12 bg-gradient-to-br from-blue-400 to-cyan-600 rounded-lg flex items-center justify-center">
              <Eye className="w-6 h-6 text-white" />
            </div>
            <div className="flex items-center gap-1 text-blue-400 text-sm">
              <TrendingUp className="w-4 h-4" />
              <span>+3.8%</span>
            </div>
          </div>
          <h3 className="text-slate-400 text-sm mb-1">{t('attention', language)}</h3>
          <p className="text-3xl font-bold text-white">72.3%</p>
          <p className="text-slate-500 text-xs mt-2">{language === 'ar' ? 'متوسط عام' : 'Overall average'}</p>
        </Card>

        <Card className="bg-gradient-to-br from-orange-500/10 to-red-600/10 border-orange-500/30 p-6">
          <div className="flex items-start justify-between mb-4">
            <div className="w-12 h-12 bg-gradient-to-br from-orange-400 to-red-600 rounded-lg flex items-center justify-center">
              <Zap className="w-6 h-6 text-white" />
            </div>
            <div className="flex items-center gap-1 text-green-400 text-sm">
              <TrendingUp className="w-4 h-4" />
              <span>-2.1%</span>
            </div>
          </div>
          <h3 className="text-slate-400 text-sm mb-1">{t('stress', language)}</h3>
          <p className="text-3xl font-bold text-white">32.7%</p>
          <p className="text-slate-500 text-xs mt-2">{language === 'ar' ? 'متوسط عام (منخفض أفضل)' : 'Overall average (lower is better)'}</p>
        </Card>

        <Card className="bg-gradient-to-br from-purple-500/10 to-pink-600/10 border-purple-500/30 p-6">
          <div className="flex items-start justify-between mb-4">
            <div className="w-12 h-12 bg-gradient-to-br from-purple-400 to-pink-600 rounded-lg flex items-center justify-center">
              <Users className="w-6 h-6 text-white" />
            </div>
            <div className="flex items-center gap-1 text-purple-400 text-sm">
              <TrendingUp className="w-4 h-4" />
              <span>+12%</span>
            </div>
          </div>
          <h3 className="text-slate-400 text-sm mb-1">{language === 'ar' ? 'إجمالي الأشخاص' : 'Total People'}</h3>
          <p className="text-3xl font-bold text-white">1,497</p>
          <p className="text-slate-500 text-xs mt-2">{language === 'ar' ? 'تم اكتشافهم اليوم' : 'Detected today'}</p>
        </Card>
      </div>

      {/* Time Series Chart */}
      <Card className="bg-slate-900/50 backdrop-blur-xl border-slate-800/50 p-6">
        <h2 className="text-xl font-bold text-white mb-6">
          {language === 'ar' ? 'الاتجاهات على مدار الوقت' : 'Trends Over Time'}
        </h2>
        <ResponsiveContainer width="100%" height={300}>
          <AreaChart data={hourlyData}>
            <defs>
              <linearGradient id="colorSatisfaction" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor={stateColors.satisfaction.high} stopOpacity={0.3}/>
                <stop offset="95%" stopColor={stateColors.satisfaction.high} stopOpacity={0}/>
              </linearGradient>
              <linearGradient id="colorAttention" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor={stateColors.attention.high} stopOpacity={0.3}/>
                <stop offset="95%" stopColor={stateColors.attention.high} stopOpacity={0}/>
              </linearGradient>
              <linearGradient id="colorStress" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor={stateColors.stress.high} stopOpacity={0.3}/>
                <stop offset="95%" stopColor={stateColors.stress.high} stopOpacity={0}/>
              </linearGradient>
            </defs>
            <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
            <XAxis dataKey="hour" stroke="#94a3b8" />
            <YAxis stroke="#94a3b8" />
            <Tooltip 
              contentStyle={{ backgroundColor: '#1e293b', border: '1px solid #334155', borderRadius: '8px' }}
              labelStyle={{ color: '#e2e8f0' }}
            />
            <Legend />
            <Area type="monotone" dataKey="satisfaction" stroke={stateColors.satisfaction.high} fillOpacity={1} fill="url(#colorSatisfaction)" name={t('satisfaction', language)} />
            <Area type="monotone" dataKey="attention" stroke={stateColors.attention.high} fillOpacity={1} fill="url(#colorAttention)" name={t('attention', language)} />
            <Area type="monotone" dataKey="stress" stroke={stateColors.stress.high} fillOpacity={1} fill="url(#colorStress)" name={t('stress', language)} />
          </AreaChart>
        </ResponsiveContainer>
      </Card>

      {/* Context Comparison */}
      <Card className="bg-slate-900/50 backdrop-blur-xl border-slate-800/50 p-6">
        <h2 className="text-xl font-bold text-white mb-6">
          {language === 'ar' ? 'مقارنة السياقات' : 'Context Comparison'}
        </h2>
        <ResponsiveContainer width="100%" height={350}>
          <BarChart data={contextData}>
            <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
            <XAxis dataKey="name" stroke="#94a3b8" />
            <YAxis stroke="#94a3b8" />
            <Tooltip 
              contentStyle={{ backgroundColor: '#1e293b', border: '1px solid #334155', borderRadius: '8px' }}
              labelStyle={{ color: '#e2e8f0' }}
            />
            <Legend />
            <Bar dataKey="satisfaction" fill={stateColors.satisfaction.high} name={t('satisfaction', language)} />
            <Bar dataKey="attention" fill={stateColors.attention.high} name={t('attention', language)} />
            <Bar dataKey="stress" fill={stateColors.stress.high} name={t('stress', language)} />
          </BarChart>
        </ResponsiveContainer>
      </Card>

      {/* Distribution Pie Charts */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card className="bg-slate-900/50 backdrop-blur-xl border-slate-800/50 p-6">
          <h3 className="text-lg font-bold text-white mb-4 text-center">
            {t('satisfaction', language)} {language === 'ar' ? 'التوزيع' : 'Distribution'}
          </h3>
          <ResponsiveContainer width="100%" height={200}>
            <PieChart>
              <Pie
                data={satisfactionDistribution}
                cx="50%"
                cy="50%"
                innerRadius={60}
                outerRadius={80}
                paddingAngle={2}
                dataKey="value"
              >
                {satisfactionDistribution.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.color} />
                ))}
              </Pie>
              <Tooltip 
                contentStyle={{ backgroundColor: '#1e293b', border: '1px solid #334155', borderRadius: '8px' }}
              />
            </PieChart>
          </ResponsiveContainer>
          <div className="mt-4 space-y-2">
            {satisfactionDistribution.map((item, i) => (
              <div key={i} className="flex items-center justify-between text-sm">
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 rounded-full" style={{ backgroundColor: item.color }} />
                  <span className="text-slate-400">{item.name}</span>
                </div>
                <span className="text-white font-medium">{item.value}%</span>
              </div>
            ))}
          </div>
        </Card>

        <Card className="bg-slate-900/50 backdrop-blur-xl border-slate-800/50 p-6">
          <h3 className="text-lg font-bold text-white mb-4 text-center">
            {t('attention', language)} {language === 'ar' ? 'التوزيع' : 'Distribution'}
          </h3>
          <ResponsiveContainer width="100%" height={200}>
            <PieChart>
              <Pie
                data={attentionDistribution}
                cx="50%"
                cy="50%"
                innerRadius={60}
                outerRadius={80}
                paddingAngle={2}
                dataKey="value"
              >
                {attentionDistribution.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.color} />
                ))}
              </Pie>
              <Tooltip 
                contentStyle={{ backgroundColor: '#1e293b', border: '1px solid #334155', borderRadius: '8px' }}
              />
            </PieChart>
          </ResponsiveContainer>
          <div className="mt-4 space-y-2">
            {attentionDistribution.map((item, i) => (
              <div key={i} className="flex items-center justify-between text-sm">
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 rounded-full" style={{ backgroundColor: item.color }} />
                  <span className="text-slate-400">{item.name}</span>
                </div>
                <span className="text-white font-medium">{item.value}%</span>
              </div>
            ))}
          </div>
        </Card>

        <Card className="bg-slate-900/50 backdrop-blur-xl border-slate-800/50 p-6">
          <h3 className="text-lg font-bold text-white mb-4 text-center">
            {t('stress', language)} {language === 'ar' ? 'التوزيع' : 'Distribution'}
          </h3>
          <ResponsiveContainer width="100%" height={200}>
            <PieChart>
              <Pie
                data={stressDistribution}
                cx="50%"
                cy="50%"
                innerRadius={60}
                outerRadius={80}
                paddingAngle={2}
                dataKey="value"
              >
                {stressDistribution.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.color} />
                ))}
              </Pie>
              <Tooltip 
                contentStyle={{ backgroundColor: '#1e293b', border: '1px solid #334155', borderRadius: '8px' }}
              />
            </PieChart>
          </ResponsiveContainer>
          <div className="mt-4 space-y-2">
            {stressDistribution.map((item, i) => (
              <div key={i} className="flex items-center justify-between text-sm">
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 rounded-full" style={{ backgroundColor: item.color }} />
                  <span className="text-slate-400">{item.name}</span>
                </div>
                <span className="text-white font-medium">{item.value}%</span>
              </div>
            ))}
          </div>
        </Card>
      </div>
    </div>
  );
};
