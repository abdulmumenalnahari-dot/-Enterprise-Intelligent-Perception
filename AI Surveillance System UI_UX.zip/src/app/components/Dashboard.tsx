import React, { useState, useEffect } from 'react';
import { useApp } from '../contexts/AppContext';
import { t } from '../i18n/translations';
import { 
  Camera, 
  Users, 
  AlertTriangle, 
  Activity,
  TrendingUp,
  TrendingDown,
  Eye,
  Play,
  Pause
} from 'lucide-react';
import { Card } from './ui/card';

export const Dashboard: React.FC<{ onNavigate: (page: string) => void }> = ({ onNavigate }) => {
  const { language, stateColors } = useApp();
  const [isLive, setIsLive] = useState(true);
  const [stats, setStats] = useState({
    totalCameras: 24,
    onlineCameras: 22,
    peopleDetected: 147,
    activeAlerts: 3,
    avgSatisfaction: 82,
    avgAttention: 76,
    avgStress: 34
  });

  // Simulate real-time updates
  useEffect(() => {
    if (!isLive) return;
    
    const interval = setInterval(() => {
      setStats(prev => ({
        ...prev,
        peopleDetected: prev.peopleDetected + Math.floor(Math.random() * 5) - 2,
        avgSatisfaction: Math.max(0, Math.min(100, prev.avgSatisfaction + Math.floor(Math.random() * 6) - 3)),
        avgAttention: Math.max(0, Math.min(100, prev.avgAttention + Math.floor(Math.random() * 6) - 3)),
        avgStress: Math.max(0, Math.min(100, prev.avgStress + Math.floor(Math.random() * 6) - 3))
      }));
    }, 3000);

    return () => clearInterval(interval);
  }, [isLive]);

  const statCards = [
    {
      icon: Camera,
      label: t('totalCameras', language),
      value: stats.totalCameras,
      subValue: `${stats.onlineCameras} ${t('online', language)}`,
      color: 'from-cyan-500 to-blue-600',
      trend: '+2',
      onClick: () => onNavigate('cameraWall')
    },
    {
      icon: Users,
      label: t('peopleDetected', language),
      value: stats.peopleDetected,
      subValue: language === 'ar' ? 'في الوقت الفعلي' : 'Real-time',
      color: 'from-purple-500 to-pink-600',
      trend: '+12',
      live: true
    },
    {
      icon: AlertTriangle,
      label: t('activeAlerts', language),
      value: stats.activeAlerts,
      subValue: language === 'ar' ? 'تحتاج إلى انتباه' : 'Need attention',
      color: 'from-orange-500 to-red-600',
      onClick: () => onNavigate('alerts')
    },
    {
      icon: Activity,
      label: t('systemStatus', language),
      value: t('healthy', language),
      subValue: '99.8% ' + (language === 'ar' ? 'وقت التشغيل' : 'Uptime'),
      color: 'from-green-500 to-emerald-600',
      trend: 'up'
    }
  ];

  const contexts = [
    { name: t('university', language), cameras: 8, people: 45, satisfaction: 85 },
    { name: t('supermarket', language), cameras: 6, people: 52, satisfaction: 78 },
    { name: t('serviceCounter', language), cameras: 4, people: 18, satisfaction: 72 },
    { name: t('meetingRoom', language), cameras: 3, people: 12, satisfaction: 88 },
    { name: t('airport', language), cameras: 3, people: 20, satisfaction: 80 }
  ];

  return (
    <div className="space-y-6">
      {/* Live Status Banner */}
      <div className="bg-gradient-to-r from-slate-800/50 to-slate-900/50 backdrop-blur-xl border border-slate-700/50 rounded-xl p-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            {isLive ? (
              <>
                <div className="relative">
                  <div className="w-3 h-3 bg-red-500 rounded-full animate-pulse" />
                  <div className="absolute inset-0 w-3 h-3 bg-red-500 rounded-full animate-ping" />
                </div>
                <span className="text-white font-medium">{language === 'ar' ? 'البث المباشر نشط' : 'Live Monitoring Active'}</span>
              </>
            ) : (
              <>
                <div className="w-3 h-3 bg-gray-500 rounded-full" />
                <span className="text-slate-400">{language === 'ar' ? 'البث متوقف' : 'Monitoring Paused'}</span>
              </>
            )}
          </div>
          <button
            onClick={() => setIsLive(!isLive)}
            className={`flex items-center gap-2 px-4 py-2 rounded-lg transition-all ${
              isLive
                ? 'bg-red-500/20 text-red-400 hover:bg-red-500/30'
                : 'bg-green-500/20 text-green-400 hover:bg-green-500/30'
            }`}
          >
            {isLive ? (
              <>
                <Pause className="w-4 h-4" />
                <span>{language === 'ar' ? 'إيقاف' : 'Pause'}</span>
              </>
            ) : (
              <>
                <Play className="w-4 h-4" />
                <span>{language === 'ar' ? 'بدء' : 'Resume'}</span>
              </>
            )}
          </button>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {statCards.map((stat, index) => {
          const Icon = stat.icon;
          return (
            <div
              key={index}
              onClick={stat.onClick}
              className={`bg-slate-900/50 backdrop-blur-xl border border-slate-800/50 rounded-xl p-6 ${
                stat.onClick ? 'cursor-pointer hover:border-slate-700 transition-all hover:shadow-lg' : ''
              }`}
            >
              <div className="flex items-start justify-between mb-4">
                <div className={`w-12 h-12 bg-gradient-to-br ${stat.color} rounded-lg shadow-lg flex items-center justify-center`}>
                  <Icon className="w-6 h-6 text-white" />
                </div>
                {stat.trend && (
                  <div className={`flex items-center gap-1 px-2 py-1 rounded-lg ${
                    stat.trend === 'up' || stat.trend.startsWith('+')
                      ? 'bg-green-500/20 text-green-400'
                      : 'bg-red-500/20 text-red-400'
                  }`}>
                    {stat.trend === 'up' ? (
                      <TrendingUp className="w-3 h-3" />
                    ) : stat.trend.startsWith('+') ? (
                      <TrendingUp className="w-3 h-3" />
                    ) : (
                      <TrendingDown className="w-3 h-3" />
                    )}
                    <span className="text-xs font-medium">{stat.trend}</span>
                  </div>
                )}
              </div>
              <div className="space-y-1">
                <p className="text-slate-400 text-sm">{stat.label}</p>
                <p className="text-2xl font-bold text-white">{stat.value}</p>
                <p className="text-slate-500 text-xs flex items-center gap-1">
                  {stat.live && <span className="w-1.5 h-1.5 bg-green-500 rounded-full animate-pulse" />}
                  {stat.subValue}
                </p>
              </div>
            </div>
          );
        })}
      </div>

      {/* Behavioral Metrics */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <Card className="bg-slate-900/50 backdrop-blur-xl border-slate-800/50 p-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-white font-medium">{t('satisfaction', language)}</h3>
            <span className="text-2xl font-bold text-green-400">{stats.avgSatisfaction}%</span>
          </div>
          <div className="h-3 bg-slate-800 rounded-full overflow-hidden">
            <div
              className="h-full bg-gradient-to-r from-green-500 to-emerald-600 transition-all duration-500 rounded-full"
              style={{ width: `${stats.avgSatisfaction}%` }}
            />
          </div>
          <p className="text-slate-500 text-xs mt-2">{language === 'ar' ? 'متوسط الرضا العام' : 'Overall satisfaction average'}</p>
        </Card>

        <Card className="bg-slate-900/50 backdrop-blur-xl border-slate-800/50 p-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-white font-medium">{t('attention', language)}</h3>
            <span className="text-2xl font-bold text-blue-400">{stats.avgAttention}%</span>
          </div>
          <div className="h-3 bg-slate-800 rounded-full overflow-hidden">
            <div
              className="h-full bg-gradient-to-r from-blue-500 to-cyan-600 transition-all duration-500 rounded-full"
              style={{ width: `${stats.avgAttention}%` }}
            />
          </div>
          <p className="text-slate-500 text-xs mt-2">{language === 'ar' ? 'متوسط مستوى الانتباه' : 'Average attention level'}</p>
        </Card>

        <Card className="bg-slate-900/50 backdrop-blur-xl border-slate-800/50 p-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-white font-medium">{t('stress', language)}</h3>
            <span className="text-2xl font-bold text-orange-400">{stats.avgStress}%</span>
          </div>
          <div className="h-3 bg-slate-800 rounded-full overflow-hidden">
            <div
              className="h-full bg-gradient-to-r from-orange-500 to-red-600 transition-all duration-500 rounded-full"
              style={{ width: `${stats.avgStress}%` }}
            />
          </div>
          <p className="text-slate-500 text-xs mt-2">{language === 'ar' ? 'متوسط مستوى الإجهاد' : 'Average stress level'}</p>
        </Card>
      </div>

      {/* Context Overview */}
      <Card className="bg-slate-900/50 backdrop-blur-xl border-slate-800/50 p-6">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-xl font-bold text-white">{language === 'ar' ? 'نظرة عامة على السياقات' : 'Context Overview'}</h2>
          <button 
            onClick={() => onNavigate('cameraWall')}
            className="text-cyan-400 hover:text-cyan-300 text-sm flex items-center gap-2"
          >
            <Eye className="w-4 h-4" />
            {t('view', language)}
          </button>
        </div>
        <div className="space-y-4">
          {contexts.map((context, index) => (
            <div
              key={index}
              className="bg-slate-800/30 border border-slate-700/50 rounded-lg p-4 hover:border-slate-600 transition-all cursor-pointer"
              onClick={() => onNavigate('cameraWall')}
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-4">
                  <div className="w-10 h-10 bg-gradient-to-br from-cyan-500/20 to-blue-600/20 rounded-lg flex items-center justify-center">
                    <Camera className="w-5 h-5 text-cyan-400" />
                  </div>
                  <div>
                    <h4 className="text-white font-medium">{context.name}</h4>
                    <p className="text-slate-400 text-sm">
                      {context.cameras} {t('cameras', language)} • {context.people} {language === 'ar' ? 'شخص' : 'people'}
                    </p>
                  </div>
                </div>
                <div className="text-right">
                  <div className={`text-sm font-medium ${
                    context.satisfaction >= 80 ? 'text-green-400' :
                    context.satisfaction >= 60 ? 'text-yellow-400' : 'text-red-400'
                  }`}>
                    {context.satisfaction}%
                  </div>
                  <div className="text-xs text-slate-500">{t('satisfaction', language)}</div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </Card>
    </div>
  );
};
