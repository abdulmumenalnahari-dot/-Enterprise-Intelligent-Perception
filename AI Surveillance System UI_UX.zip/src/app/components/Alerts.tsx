import React, { useState } from 'react';
import { useApp } from '../contexts/AppContext';
import { t } from '../i18n/translations';
import { Alert as AlertType } from '../types';
import { Card } from './ui/card';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { AlertTriangle, CheckCircle, Clock, Camera, User, Shield, Activity, Filter } from 'lucide-react';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';

export const Alerts: React.FC = () => {
  const { language, stateColors } = useApp();
  const [filter, setFilter] = useState<'all' | 'active' | 'acknowledged'>('active');
  const [severityFilter, setSeverityFilter] = useState<'all' | 'low' | 'medium' | 'high' | 'critical'>('all');

  const [alerts, setAlerts] = useState<AlertType[]>([
    {
      id: 'A001',
      type: 'behavior',
      severity: 'high',
      title: language === 'ar' ? 'انخفاض مستوى الرضا' : 'Low Satisfaction Detected',
      description: language === 'ar' ? 'انخفاض كبير في مستوى الرضا في منطقة كاونتر الخدمة' : 'Significant drop in satisfaction levels at Service Counter',
      cameraId: 'CAM-SC-1',
      cameraName: 'Service Counter 1',
      timestamp: new Date(Date.now() - 300000),
      acknowledged: false
    },
    {
      id: 'A002',
      type: 'security',
      severity: 'critical',
      title: language === 'ar' ? 'تحذير أمني' : 'Security Alert',
      description: language === 'ar' ? 'تم اكتشاف مستوى خطر مرتفع في منطقة المطار' : 'High risk level detected in Airport Terminal',
      cameraId: 'CAM-AP-2',
      cameraName: 'Airport Terminal 2',
      timestamp: new Date(Date.now() - 120000),
      acknowledged: false,
      personId: 'P1247'
    },
    {
      id: 'A003',
      type: 'behavior',
      severity: 'medium',
      title: language === 'ar' ? 'ارتفاع مستوى الإجهاد' : 'Elevated Stress Levels',
      description: language === 'ar' ? 'مستويات إجهاد عالية مكتشفة في السوبر ماركت' : 'High stress levels detected in Supermarket',
      cameraId: 'CAM-SM-1',
      cameraName: 'Supermarket Floor 1',
      timestamp: new Date(Date.now() - 600000),
      acknowledged: true
    },
    {
      id: 'A004',
      type: 'system',
      severity: 'medium',
      title: language === 'ar' ? 'انخفاض معدل الإطارات' : 'Camera FPS Drop',
      description: language === 'ar' ? 'انخفاض معدل الإطارات في الكاميرا' : 'Camera experiencing low frame rate',
      cameraId: 'CAM-UN-3',
      cameraName: 'University Building A 3',
      timestamp: new Date(Date.now() - 900000),
      acknowledged: true
    },
    {
      id: 'A005',
      type: 'satisfaction',
      severity: 'low',
      title: language === 'ar' ? 'تحسن الرضا' : 'Satisfaction Improvement',
      description: language === 'ar' ? 'تحسن ملحوظ في مستويات الرضا' : 'Notable improvement in satisfaction levels',
      cameraId: 'CAM-MR-1',
      cameraName: 'Meeting Room 1',
      timestamp: new Date(Date.now() - 1800000),
      acknowledged: false
    }
  ]);

  const handleAcknowledge = (id: string) => {
    setAlerts(alerts.map(alert => 
      alert.id === id ? { ...alert, acknowledged: true } : alert
    ));
  };

  const filteredAlerts = alerts.filter(alert => {
    if (filter === 'active' && alert.acknowledged) return false;
    if (filter === 'acknowledged' && !alert.acknowledged) return false;
    if (severityFilter !== 'all' && alert.severity !== severityFilter) return false;
    return true;
  });

  const getSeverityIcon = (severity: string) => {
    switch (severity) {
      case 'critical':
        return <Shield className="w-5 h-5" />;
      case 'high':
        return <AlertTriangle className="w-5 h-5" />;
      case 'medium':
        return <Activity className="w-5 h-5" />;
      default:
        return <Activity className="w-5 h-5" />;
    }
  };

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'critical':
        return stateColors.risk.critical;
      case 'high':
        return stateColors.risk.high;
      case 'medium':
        return stateColors.risk.medium;
      default:
        return stateColors.risk.low;
    }
  };

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'security':
        return Shield;
      case 'behavior':
        return User;
      case 'system':
        return Camera;
      default:
        return Activity;
    }
  };

  return (
    <div className="space-y-6">
      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card className="bg-slate-900/50 border-slate-800 p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-slate-400 text-sm">{t('activeAlerts', language)}</p>
              <p className="text-2xl font-bold text-white">
                {alerts.filter(a => !a.acknowledged).length}
              </p>
            </div>
            <div className="w-12 h-12 bg-red-500/20 rounded-lg flex items-center justify-center">
              <AlertTriangle className="w-6 h-6 text-red-400" />
            </div>
          </div>
        </Card>

        <Card className="bg-slate-900/50 border-slate-800 p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-slate-400 text-sm">{language === 'ar' ? 'حرج' : 'Critical'}</p>
              <p className="text-2xl font-bold text-red-400">
                {alerts.filter(a => a.severity === 'critical' && !a.acknowledged).length}
              </p>
            </div>
            <div className="w-12 h-12 bg-red-600/20 rounded-lg flex items-center justify-center">
              <Shield className="w-6 h-6 text-red-500" />
            </div>
          </div>
        </Card>

        <Card className="bg-slate-900/50 border-slate-800 p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-slate-400 text-sm">{language === 'ar' ? 'عالي' : 'High'}</p>
              <p className="text-2xl font-bold text-orange-400">
                {alerts.filter(a => a.severity === 'high' && !a.acknowledged).length}
              </p>
            </div>
            <div className="w-12 h-12 bg-orange-500/20 rounded-lg flex items-center justify-center">
              <AlertTriangle className="w-6 h-6 text-orange-400" />
            </div>
          </div>
        </Card>

        <Card className="bg-slate-900/50 border-slate-800 p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-slate-400 text-sm">{language === 'ar' ? 'تمت المعالجة اليوم' : 'Resolved Today'}</p>
              <p className="text-2xl font-bold text-green-400">
                {alerts.filter(a => a.acknowledged).length}
              </p>
            </div>
            <div className="w-12 h-12 bg-green-500/20 rounded-lg flex items-center justify-center">
              <CheckCircle className="w-6 h-6 text-green-400" />
            </div>
          </div>
        </Card>
      </div>

      {/* Filters */}
      <div className="flex flex-wrap items-center gap-4">
        <div className="flex gap-2 bg-slate-900/50 border border-slate-800 rounded-lg p-1">
          <button
            onClick={() => setFilter('all')}
            className={`px-4 py-2 rounded-md text-sm transition-all ${
              filter === 'all' ? 'bg-cyan-500 text-white' : 'text-slate-400 hover:text-white'
            }`}
          >
            {language === 'ar' ? 'الكل' : 'All'}
          </button>
          <button
            onClick={() => setFilter('active')}
            className={`px-4 py-2 rounded-md text-sm transition-all ${
              filter === 'active' ? 'bg-cyan-500 text-white' : 'text-slate-400 hover:text-white'
            }`}
          >
            {language === 'ar' ? 'نشط' : 'Active'}
          </button>
          <button
            onClick={() => setFilter('acknowledged')}
            className={`px-4 py-2 rounded-md text-sm transition-all ${
              filter === 'acknowledged' ? 'bg-cyan-500 text-white' : 'text-slate-400 hover:text-white'
            }`}
          >
            {language === 'ar' ? 'تمت المعالجة' : 'Acknowledged'}
          </button>
        </div>

        <Select value={severityFilter} onValueChange={(v: any) => setSeverityFilter(v)}>
          <SelectTrigger className="w-[180px] bg-slate-900/50 border-slate-800 text-white">
            <div className="flex items-center gap-2">
              <Filter className="w-4 h-4" />
              <SelectValue />
            </div>
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">{language === 'ar' ? 'جميع المستويات' : 'All Severities'}</SelectItem>
            <SelectItem value="critical">{language === 'ar' ? 'حرج' : 'Critical'}</SelectItem>
            <SelectItem value="high">{language === 'ar' ? 'عالي' : 'High'}</SelectItem>
            <SelectItem value="medium">{language === 'ar' ? 'متوسط' : 'Medium'}</SelectItem>
            <SelectItem value="low">{language === 'ar' ? 'منخفض' : 'Low'}</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* Alerts List */}
      <div className="space-y-4">
        {filteredAlerts.length === 0 ? (
          <Card className="bg-slate-900/50 border-slate-800 p-12">
            <div className="text-center">
              <CheckCircle className="w-16 h-16 text-green-400 mx-auto mb-4" />
              <p className="text-slate-400">
                {language === 'ar' ? 'لا توجد تنبيهات' : 'No alerts found'}
              </p>
            </div>
          </Card>
        ) : (
          filteredAlerts.map(alert => {
            const TypeIcon = getTypeIcon(alert.type);
            const severityColor = getSeverityColor(alert.severity);
            
            return (
              <Card
                key={alert.id}
                className={`bg-slate-900/50 border-slate-800 p-6 ${
                  alert.acknowledged ? 'opacity-60' : ''
                }`}
              >
                <div className="flex items-start gap-4">
                  <div
                    className="w-12 h-12 rounded-lg flex items-center justify-center flex-shrink-0"
                    style={{ backgroundColor: `${severityColor}20`, color: severityColor }}
                  >
                    {getSeverityIcon(alert.severity)}
                  </div>

                  <div className="flex-1">
                    <div className="flex items-start justify-between mb-2">
                      <div className="flex items-center gap-3">
                        <h3 className="text-white font-medium">{alert.title}</h3>
                        <Badge
                          variant="outline"
                          className="border-slate-700"
                          style={{ color: severityColor, borderColor: severityColor }}
                        >
                          {alert.severity.toUpperCase()}
                        </Badge>
                        {alert.acknowledged && (
                          <Badge variant="outline" className="border-green-500 text-green-400">
                            <CheckCircle className="w-3 h-3 mr-1" />
                            {language === 'ar' ? 'تمت المعالجة' : 'Acknowledged'}
                          </Badge>
                        )}
                      </div>
                      <span className="text-slate-500 text-sm flex items-center gap-1">
                        <Clock className="w-4 h-4" />
                        {formatTimestamp(alert.timestamp, language)}
                      </span>
                    </div>

                    <p className="text-slate-400 mb-3">{alert.description}</p>

                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-4 text-sm">
                        <div className="flex items-center gap-2 text-slate-400">
                          <Camera className="w-4 h-4" />
                          <span>{alert.cameraName}</span>
                        </div>
                        {alert.personId && (
                          <div className="flex items-center gap-2 text-slate-400">
                            <User className="w-4 h-4" />
                            <span>ID: {alert.personId}</span>
                          </div>
                        )}
                        <div className="flex items-center gap-2">
                          <TypeIcon className="w-4 h-4 text-slate-400" />
                          <span className="text-slate-400 capitalize">{alert.type}</span>
                        </div>
                      </div>

                      {!alert.acknowledged && (
                        <Button
                          onClick={() => handleAcknowledge(alert.id)}
                          variant="outline"
                          size="sm"
                          className="border-slate-700 text-white hover:bg-slate-800"
                        >
                          <CheckCircle className="w-4 h-4 mr-2" />
                          {t('confirm', language)}
                        </Button>
                      )}
                    </div>
                  </div>
                </div>
              </Card>
            );
          })
        )}
      </div>
    </div>
  );
};

function formatTimestamp(date: Date, language: 'ar' | 'en'): string {
  const now = new Date();
  const diff = now.getTime() - date.getTime();
  const minutes = Math.floor(diff / 60000);
  const hours = Math.floor(diff / 3600000);

  if (minutes < 1) return language === 'ar' ? 'الآن' : 'Now';
  if (minutes < 60) return language === 'ar' ? `منذ ${minutes} دقيقة` : `${minutes}m ago`;
  if (hours < 24) return language === 'ar' ? `منذ ${hours} ساعة` : `${hours}h ago`;
  return date.toLocaleString(language === 'ar' ? 'ar-SA' : 'en-US');
}
